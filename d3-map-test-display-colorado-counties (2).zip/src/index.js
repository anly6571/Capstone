import * as d3 from "d3";
import "./styles.css";
import { loadFlowerData, ready } from "./flowers.js";

// Loading Data
async function getFlowerInfo() {
  let flowerData = await loadFlowerData();
  return ready(flowerData);
}

let flowerData = getFlowerInfo();
var coloMap = d3.json("CO-counties.geojson"); //this is res[0]

// Setup the base SVG
var width = 900;
var height = 700;

var svg = d3
  .select("svg")
  .attr("preserveAspectRatio", "xMinYMin meet")
  .style("background-color", "#c9e8fd")
  .attr("viewBox", "0 0 " + width + " " + height)
  .classed("svg-content", true);

// Setup D3 Map Projection
var projection = d3
  .geoMercator()
  .translate([width / 2, height / 2])
  .scale(5300)
  .center([-105.5, 39]); //40, 104
var path = d3.geoPath().projection(projection);

// State texture and color mapping
var tilling = d3.scaleQuantize().domain([0, 75]).range(["A", "B", "C"]);
var coloring = d3.scaleQuantile().domain([0, 16]).range(["A", "B", "C"]);

// After the map and flower data is loaded...
Promise.all([coloMap, flowerData]).then((res) => {
  console.log(res[0]);
  console.log(res[1]);

  // Varables needed for flower creation
  const numData = res[1].length + 1;
  const xScale = d3.scaleLinear().domain([0, numData]).range([0, 1000]);

  const zoom = d3.zoom().scaleExtent([1, 8]).on("zoom", zoomed);

  // Overall group for elements
  const g = svg.append("g");

  // Draw Counties
  const counties = g
    .append("g")
    .attr("cursor", "pointer")
    .selectAll("path")
    .data(res[0].features)
    .enter()
    .append("path")
    .on("click", clicked)
    .attr("class", (d) => {
      let demo = res[1].find((e) => e.county === d.properties.name);
      if ( !demo ) { console.log(d)}

      return `county ${coloring(demo?.cover) || ''}${tilling(demo?.till) || ''}`;
    })
    .attr("d", path);

  // Creates petals, assigns color, scale, and position
  const flowers = g
    .append("g")
    .selectAll("g")
    .data(res[1])
    .enter()
    .append("g")
    .attr(
      "transform",
      (d, i) => `translate(${d.xPos} ${d.yPos}), scale(${d.petSize})`
    )
    .attr("fill", (d, i) => d3.interpolatePurples(d.colors))
    .attr("stroke", "black")
    .attr("opacity", 0.9);

  // Takes petals and applies scale and rotation to make flower
  flowers
    .selectAll("path")
    .data((d) => d.petals) // Array of petals from above
    .enter()
    .append("path")
    .attr("d", (d) => d.petalPath) //
    .attr("x", (d) => xScale(d.numPetals))
    .attr("transform", (d) => `rotate(${d.angle})`); //rotates each petal

  //anna is experimenting here
  const centers = g
    .selectAll()
    .data(res[0].features)
    .enter()
    .append("circle")
    .attr("cx", (d) => path.centroid(d)[0])
    .attr("cy", (d) => path.centroid(d)[1])
    .attr("r", 10)
    .attr("fill", "purple");

  svg.call(zoom);

  function reset() {
    counties.transition().style("fill", null);
    svg
      .transition()
      .duration(750)
      .call(
        zoom.transform,
        d3.zoomIdentity,
        d3.zoomTransform(svg.node()).invert([width / 2, height / 2])
      );
  }

  function clicked(event, d) {
    //console.log(d.properties.name);
    //console.log(path.centroid(d));

    // Get the bounding box of the clicked feature
    const [[x0, y0], [x1, y1]] = path.bounds(d);
    //console.log(res[0].features)
    // Stop the click event from propgating further
    event.stopPropagation();
    // Transition the fill of the clicked state.
    d3.select(this).transition().style("fill", "#326941");
    // Perform a transition on the SVG ( Output doesn't change: SVG / g / States?)
    svg
      .transition()
      .duration(750)
      .call(
        zoom.transform,
        d3.zoomIdentity
          // Move translation origin to center of the screen
          .translate(width / 2, height / 2)
          // Scale the zoom to the smaller of: level "8", or 0.9 * the largest dimension
          .scale(
            Math.min(8, 0.9 / Math.max((x1 - x0) / width, (y1 - y0) / height))
          )
          // Translate the view to the center of the bounding box
          .translate(-(x0 + x1) / 2, -(y0 + y1) / 2),
        d3.pointer(event, svg.node())
      );
  }

  function zoomed(event) {
    const { transform } = event;
    g.attr("transform", transform);
    counties.attr("stroke-width", 1 / transform.k);
  }
});
