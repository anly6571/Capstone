// TODO
// x Classes
// x Flowers Clickable
// x Biggable
// - Scroll Scroll

import * as d3 from "d3";
import "./styles.css";
import * as scrollTriggers from "./scrollTriggers";
import { loadFlowerData, ready } from "./flowers.js";

// Loading Data
async function getFlowerInfo() {
  let flowerData = await loadFlowerData();
  return ready(flowerData);
}

let flowerData = getFlowerInfo();
var coloMap = d3.json("./data/CO-counties.geojson"); //this is res[0]

// Setup the base SVG
var width = 900;
var height = 700;

var svg = d3
  .select("svg")
  .attr("preserveAspectRatio", "xMinYMin meet")
  .attr("viewBox", "0 0 " + width + " " + height)
  .classed("svg-content", true);

// Setup D3 Map Projection
var projection = d3
  .geoMercator()
  .translate([width / 2, height / 2])
  .scale(5300)
  .center([-105.5, 39]); //40, 104
var path = d3.geoPath().projection(projection);

// State texture and color mapping
var tilling = d3.scaleQuantize().domain([0, 75]).range(["A", "B", "C"]);
var coloring = d3.scaleQuantile().domain([0, 16]).range(["A", "B", "C"]);

// After the map and flower data is loaded...
Promise.all([coloMap, flowerData]).then((res) => {
  // res[0] = coloMap
  // res[1] = flowerData

  res[0].features.sort((a, b) => {
    const bleep = a.properties.name;
    const bloop = b.properties.name;
    if (bleep > bloop) return 1;
    if (bleep < bloop) return -1;
    else return 0;
  });


  // Varables needed for flower creation
  const zoom = d3.zoom().scaleExtent([1, 8]).on("zoom", zoomed);

  // Overall group for elements
  const map = svg.append("g");
  map.append("g").attr("class", "counties");

  const countiesLayer =  d3.selectAll(".counties")
    countiesLayer.attr("stroke", "black")
    countiesLayer.attr("fill-opacity", 0)

  // Add Counties
  countiesLayer
    .selectAll("g")
    .data(res[0].features)
    .enter()
    .append("g") // Add a group for each county
    .attr("class", (d) => `county ${d.properties.name.replace(/ /g, "_")}`)
    .on("click", clicked)
    .append("path") // Draw shape for each county
    .attr("class", (d) => {
      let demo = res[1].find((e) => e.county === d.properties.name);
      return `shape ${coloring(demo?.cover) || ""}${tilling(demo?.till) || ""}`;
    })
    .attr("d", path);

  const countySelect = d3.selectAll(".county")

  map.append("g").attr("class", "flowers")

  const flowersLayer = d3.select(".flowers")
   flowersLayer.attr("stroke", "black")
   flowersLayer.attr("stroke-opacity", 0)
   flowersLayer.attr("stroke-weight", 1)
   flowersLayer.attr("fill-opacity", 0)
   

  // Creates flowers with petals
  flowersLayer
    .selectAll("g")
    .data(res[1])
    .enter()
    .append("g")
    .on("click", (event, d) => {
      event.stopPropagation();
      let path = res[0].features.find((el) => d.county === el.properties.name);
      clicked(event, path);
    })
    .attr("class", (d) => `flower ${d.county.replace(/ /g, "_")}`)
    .attr(
      "transform",
      (d) => `translate(${d.xPos} ${d.yPos}), scale(${d.petSize})`
    )
    .attr("fill", (d) => d3.interpolateMagma(d.colors))
    .selectAll("path")
    .data((d) => d.petals)
    .enter()
    .append("path")
    .attr("class", "petal")
    .attr("d", (d) => d.petalPath)
    .attr("transform", (d) => `rotate(${d.angle})`);

  const flowerSelect = d3.selectAll(".flower");

  // Add flower centers
  flowerSelect
    .append("circle")
    .attr("fill", "white")
    .attr("stroke", "none")
    .attr("cx", 0)
    .attr("cy", 0)
    .attr("r", 20);

  function resetVis() {
    //counties layer att opacity -> 0
    //
  }
 
 
  function shapeStroke() {
    console.log(flowersLayer);
    countiesLayer
    //add
        .transition()
        .duration(750)
        .attr("stroke", "white")
    //subtract
        .attr("fill-opacity", 0)
    flowersLayer
        .attr("stroke-opacity", 0)
        .attr("fill-opacity", 0)

  }
  function shapeColor() {
    //add
    countiesLayer
        .transition()
        .duration(750)
        .attr("fill-opacity", 1)
    //subtract
    flowersLayer
        .transition()
        .duration(750)
        .attr("stroke-opacity", "0")
  }
   function flowerStroke() {
    flowersLayer
    //add
        .transition()
        .duration(850)
        .attr("stroke-opacity", "1")
        .attr("stroke-width", "5")
    // subtract    
        .attr("fill-opacity", 0)
  }
  function flowerColor() {
    flowersLayer
    //add
        .transition()
        .duration(750)
        .attr("fill-opacity", 1)
    //subtract
        .attr("stroke-opacity", 0)
  }

  scrollTriggers.addTrigger("Trigger1", 20, shapeStroke)
  scrollTriggers.addTrigger("Trigger2", 20, shapeColor)
  scrollTriggers.addTrigger("Trigger3", 20, flowerStroke)
  scrollTriggers.addTrigger("Trigger4", 20, flowerColor)

  svg.call(zoom);

  function reset() {
    // Not used, yet?
    svg
      .transition()
      .duration(750)
      .call(
        zoom.transform,
        d3.zoomIdentity,
        d3.zoomTransform(svg.node()).invert([width / 2, height / 2])
      );
  }

  function clicked(event, d) {
    // Get the bounding box of the clicked feature
    const [[x0, y0], [x1, y1]] = path.bounds(d);

    // Stop the click event from propgating further
    event.stopPropagation();

    // Perform a transition on the SVG
    svg
      .transition()
      .duration(750)
      .call(
        zoom.transform,
        d3.zoomIdentity
          // Move translation origin to center of the screen
          .translate(width / 2, height / 2)
          // Scale the zoom to the smaller of: level "8", or 0.9 * the largest dimension
          .scale(
            Math.min(8, 0.9 / Math.max((x1 - x0) / width, (y1 - y0) / height))
          )
          // Translate the view to the center of the bounding box
          .translate(-(x0 + x1) / 2, -(y0 + y1) / 2),
        d3.pointer(event, svg.node())
      );
  }

  function zoomed(event) {
    const { transform } = event;
    map.attr("transform", transform);
    map.attr("stroke-width", 1 / transform.k);
  }
});
