import * as d3 from "d3";
import "./styles.css";
import * as _ from "lodash";
import { loadFlowerData, ready } from "./flowers.js";

var width = 900;
var height = 700;

async function getFlowerInfo() {
  let flowerData = await loadFlowerData();
  return ready(flowerData);
}

let flowerData = getFlowerInfo();

let petalPath = "M 0,0 C -10, -10 -10, -40 0, -50 C 10, -40 10, -10, 0,0 ";
// load data
var coloMap = d3.json("CO-counties.geojson"); //this is res[0]

//base SVG
var svg = d3
  .select("div#container")
  .append("svg")
  .attr("preserveAspectRatio", "xMinYMin meet")
  .style("background-color", "#c9e8fd")
  .attr("viewBox", "0 0 " + width + " " + height)
  .classed("svg-content", true);

//projection
var projection = d3
  .geoMercator()
  .translate([width / 2, height / 2])
  .scale(5300)
  .center([-105.5, 39]); //40, 104
var path = d3.geoPath().projection(projection);

//console.log(flowersData[0].petals)

Promise.all([coloMap, flowerData]).then((res) => {

  const numData = res[1].length + 1;
  const energyMinMax = d3.extent(res[1], (d) => d.energy);
  const ghgMinMax = d3.extent(res[1], (d) => d.ghg);
  const sizeScale = d3.scaleLinear().domain(energyMinMax).range([0.25, 1]); //size mapped to energy
  const numPetalScale = d3.scaleQuantize().domain(ghgMinMax).range([5, 7, 12]); //number mapped to ghg
  const xScale = d3.scaleLinear().domain([0, numData]).range([0, 1000]);
  let petalSize = 50;

  const zoom = d3.zoom()
    .scaleExtent([1, 8])
    .on("zoom", zoomed);

  // Overall group for elements
  const g = svg.append("g")

  // 
  const counties = g.append("g")
    .attr("cursor", "pointer")
    .selectAll("path")
    .data(res[0].features)
    .enter()
    .append("path")
      .on("click", clicked)
      .attr("class", "county")
      .attr("d", path)
    
  let petals = g.append("g")
    .selectAll()
    .data(res[0].features)
    .enter()
    .append("path")
      .attr("transform", (d) => `translate(${path.centroid(d)}) rotate(45)`)
      .attr("d", petalPath)
      .attr("fill", "blue");

      const flowers = g.append("g")
      .selectAll("g")
      .data(res[1])
      .enter()
      .append("g")
      .attr(
        "transform",
        (d, i) =>
          `translate(${
            petalSize + (i - 1) * (2 * petalSize)
          },${petalSize} )scale(${d.petSize})`
      );
  
    flowers
      .selectAll("path")
      .data((d) => d.petals) //array of petals from above
      .enter()
      .append("path")
      .attr("d", (d) => d.petalPath) //
      .attr("x", (d) => xScale(d.numPetals))
      .attr("transform", (d) => `rotate(${d.angle})`) //rotates each petal
      .attr("fill", (d, i) => d3.interpolateBlues(d.angle / 360));

  svg.call(zoom);

  function reset() {
    counties.transition().style("fill", null);
    svg.transition().duration(750).call(
      zoom.transform,
      d3.zoomIdentity,
      d3.zoomTransform(svg.node()).invert([width / 2, height / 2])
    );
  }

  function clicked(event, d) {
    console.log(d)
    // Get the bounding box of the clicked feature
      const [[x0, y0], [x1, y1]] = path.bounds(d);
    // Stop the click event from propgating further
      event.stopPropagation();
    // Transition the fill of the clicked state.
      d3.select(this).transition().style("fill", "#326941");
    // Perform a transition on the SVG ( Output doesn't change: SVG / g / States?)
      svg.transition().duration(750).call(
        zoom.transform,
          d3.zoomIdentity
          // Move translation origin to center of the screen
            .translate(width / 2, height / 2)
          // Scale the zoom to the smaller of: level "8", or 0.9 * the largest dimension
            .scale(Math.min(8, 0.9 / Math.max((x1 - x0) / width, (y1 - y0) / height)))
          // Translate the view to the center of the bounding box
            .translate(-(x0 + x1) / 2, -(y0 + y1) / 2),
        d3.pointer(event, svg.node())
    );
  }

  function zoomed(event) {
    const { transform } = event;
    //console.log(transform)
    // flowers.attr("transform", d => {
    //   const centroid = path.centroid(d)
    //   return transform.translate(centroid[0], centroid[1])
    // })
    g.attr("transform", transform);
    counties.attr("stroke-width", 1 / transform.k);
  } 
});

//path.centroid(res);
