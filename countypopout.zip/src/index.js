import * as d3 from "d3";
import "./styles.css";

//resources//
// https://stackoverflow.com/questions/64246633/pop-out-svg-us-state-feature-path-on-click

var coloMap = d3.json("CO-counties.geojson"); //this is res[0]

// Setup the base SVG
var w = 900;
var h = 700;

var svg = d3
  .select("svg")
  .attr("preserveAspectRatio", "xMinYMin meet")
  .style("background-color", "#c9e8fd")
  .attr("viewBox", "0 0 " + w + " " + h)
  .classed("svg-content", true);

// Setup D3 Map Projection
var projection = d3
  .geoMercator()
  .translate([w / 2, h / 2])
  .scale(5300)
  .center([-105.5, 39]); //40, 104
var path = d3.geoPath().projection(projection);

// State texture and color mapping
var tilling = d3.scaleQuantize().domain([0, 75]).range(["A", "B", "C"]);
var coloring = d3.scaleQuantile().domain([0, 16]).range(["A", "B", "C"]);

// After the map and flower data is loaded...
Promise.all([coloMap]).then((res) => {
  //console.log(res[0]);

//  const zoom = d3.zoom().scaleExtent([1, 8]).on("zoom", zoomed);

  // Overall group for elements
  const g = svg.append("g");

  // Draw Counties
  svg.append("circle")
    .attr("cx", 450)
    .attr("cy", 350)
    .attr("r", 10)
    .attr("fill", "green")
  const countiesContainer = svg.append("g");
  const counties = g
  .append("g")
    //.attr("cursor", "pointer")
    .selectAll("path")
    .data(res[0].features)
    .enter()
    .append("path")
    //.on("click", clicked) // old .on
    .attr("class", "county")
    .style("stroke", "white")
    .attr("d", path)
    .on("click", function(event, d) {
      const { x,y,width,height } = this.getBBox(); //returns rectangle (center, width, height)

      // transform county to be in front
      const county = d3.select(this)
      .attr("transform-origin", `${x + width / 2}px ${y + height / 2}px`).remove();
      countiesContainer.append(() => county.node());
      //.remove() and .append() removes it from OG map and moves it to container
      county.attr("fill", "red")
      d.properties.expanded = !d.properties.expanded;
      //Adds transition and sets size * 5 of original and back to OG when clicked again
      county
        .transition()
        .duration(100)
        .attr("transform", d.properties.expanded ? `translate(${450 - (x+(width/2))} ${350-(y+(height/2))}) scale(5)` : "scale(1)")
    });
});
